const express = require("express");
const cors = require("cors");
const multer = require("multer");
const { Low, JSONFile } = require("lowdb");
const QRCode = require("qrcode");
const path = require("path");

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));
app.use("/uploads", express.static("uploads"));

// ================= DATABASE =================
const adapter = new JSONFile("db.json");

const db = new Low(adapter, {
  users: [],
  campaigns: [],
  attendance: [],
  proofs: []
});

async function initDB() {
  await db.read();
  db.data ||= {
    users: [],
    campaigns: [],
    attendance: [],
    proofs: []
  };
  await db.write();
}
initDB();

// ================= FILE UPLOAD =================
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  }
});

const upload = multer({ storage });

// ================= REGISTER =================
app.post("/register", async (req, res) => {
  await db.read();

  const { email, password, role } = req.body;

  const exists = db.data.users.find(u => u.email === email);
  if (exists) {
    return res.json({ success: false, message: "User already exists" });
  }

  db.data.users.push({
    id: Date.now(),
    email,
    password,
    role: role || "volunteer",
    points: 0,
    attendance: 0,
    level: 1,
    history: [],
    lastLocation: null,
    punchIn: null
  });

  await db.write();

  res.json({ success: true, message: "Registered Successfully" });
});

// ================= LOGIN =================
app.post("/login", async (req, res) => {
  await db.read();

  const { email, password } = req.body;

  const user = db.data.users.find(u => u.email === email);

  if (!user) {
    return res.json({ success: false, message: "User not found" });
  }

  if (user.password !== password) {
    return res.json({ success: false, message: "Incorrect password" });
  }

  res.json({ success: true, user });
});

// ================= LEADERBOARD =================
app.get("/users", async (req, res) => {
  await db.read();

  const sorted = db.data.users
    .map(u => ({
      email: u.email,
      points: u.points,
      attendance: u.attendance,
      level: u.level
    }))
    .sort((a, b) => b.points - a.points);

  res.json(sorted);
});

// ================= PUNCH IN =================
app.post("/punch-in", async (req, res) => {
  await db.read();

  const user = db.data.users.find(u => u.email === req.body.email);
  if (!user) return res.json({ message: "User not found" });

  user.punchIn = new Date();
  await db.write();

  res.json({ message: "Punch In Successful ⏱️" });
});

// ================= PUNCH OUT =================
app.post("/punch-out", async (req, res) => {
  await db.read();

  const user = db.data.users.find(u => u.email === req.body.email);
  if (!user || !user.punchIn) {
    return res.json({ message: "Punch In not found" });
  }

  const hours =
    (new Date() - new Date(user.punchIn)) / (1000 * 60 * 60);

  user.attendance += 1;
  user.points += Math.floor(hours * 5);

  if (user.points >= 200) user.level = 3;
  else if (user.points >= 100) user.level = 2;

  user.punchIn = null;

  await db.write();

  res.json({ message: "Punch Out Successful ✅" });
});

// ================= IMAGE UPLOAD =================
app.post("/upload", upload.single("image"), async (req, res) => {
  await db.read();

  const user = db.data.users.find(u => u.email === req.body.email);
  if (!user) return res.json({ message: "User not found" });

  if (!req.file) return res.json({ message: "No file uploaded" });

  let aiDetected = false;

  if (req.file.mimetype.includes("image")) {
    const name = req.file.originalname.toLowerCase();

    if (
      name.includes("tree") ||
      name.includes("plant") ||
      name.includes("clean") ||
      name.includes("plastic")
    ) {
      aiDetected = true;
    }
  }

  if (aiDetected) {
    user.points += 10;

    user.history.push({
      type: "AI Auto Approval",
      date: new Date(),
      comment: "AI verified eco activity"
    });

    await db.write();

    return res.json({
      message: "AI Verified ✅ +10 Points Added"
    });
  }

  db.data.proofs.push({
    id: Date.now(),
    email: user.email,
    filename: req.file.filename,
    status: "Pending",
    comment: ""
  });

  await db.write();

  res.json({ message: "Submitted for Admin Approval 🕒" });
});

// ================= APPROVE PROOF =================
app.post("/approve-proof", async (req, res) => {
  await db.read();

  const proof = db.data.proofs.find(p => p.id == req.body.id);
  if (!proof) return res.json({ message: "Proof not found" });

  const user = db.data.users.find(u => u.email === proof.email);

  proof.status = "Approved";
  proof.comment = req.body.comment || "";

  user.points += 20;

  user.history.push({
    type: "Admin Approval",
    date: new Date(),
    comment: proof.comment
  });

  await db.write();

  res.json({ message: "Proof Approved +20 Points ✅" });
});

// ================= REJECT PROOF =================
app.post("/reject-proof", async (req, res) => {
  await db.read();

  const proof = db.data.proofs.find(p => p.id == req.body.id);
  if (!proof) return res.json({ message: "Proof not found" });

  proof.status = "Rejected";
  proof.comment = req.body.comment || "";

  await db.write();

  res.json({ message: "Proof Rejected ❌" });
});

// ================= GPS CHECK =================
app.post("/gps-check", async (req, res) => {
  await db.read();

  const user = db.data.users.find(u => u.email === req.body.email);
  if (!user) return res.json({ message: "User not found" });

  user.lastLocation = {
    lat: req.body.lat,
    long: req.body.long,
    date: new Date()
  };

  await db.write();

  res.json({ message: "Location Verified ✅" });
});

// ================= QR GENERATOR =================
app.get("/generate-qr", async (req, res) => {
  const qr = await QRCode.toDataURL(
    "eco-attendance-" + new Date().toDateString()
  );
  res.send(`<img src="${qr}" />`);
});

// ================= DEFAULT ROUTE =================
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "login.html"));
});

// ================= START SERVER =================
app.listen(5000, () => {
  console.log("Professional NGO Server Running on http://localhost:5000 🚀");
});